package com.drwael.admin;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.RemoteViews;

import androidx.core.content.res.ResourcesCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * ويدجت الشاشة الرئيسية: عدّادات الدعم والمدفوعات والجروب والطلاب الجدد منذ آخر فتح للتطبيق.
 * يُرسم كصورة بنفس خط التطبيق (AJ) وبنفس اللوجو. لا يعرض أسماء ولا نصوص رسائل (خصوصية).
 */
public class DwWidget extends AppWidgetProvider {
    static final String[] KINDS = {"support", "pay", "group", "signup"};
    private static final String[] LABELS = {"الدعم", "المدفوعات", "الجروب", "طلاب جدد"};
    private static final int[] COLORS = {0xFFF5A83A, 0xFF2FD39A, 0xFF6CB4FF, 0xFFFF7BA9};

    // ---------- المخزن ----------
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("dw_widget", Context.MODE_PRIVATE); }

    static void bump(Context c, String kind) {
        for (String k : KINDS) {
            if (k.equals(kind)) {
                SharedPreferences p = sp(c);
                p.edit().putInt("n_" + k, p.getInt("n_" + k, 0) + 1).putLong("last", System.currentTimeMillis()).apply();
                refresh(c);
                return;
            }
        }
    }

    static void clear(Context c) {
        SharedPreferences p = sp(c);
        boolean any = false;
        SharedPreferences.Editor e = p.edit();
        for (String k : KINDS) if (p.getInt("n_" + k, 0) != 0) { e.remove("n_" + k); any = true; }
        e.apply();
        if (any) refresh(c);
    }

    // ---------- الاستقبال ----------
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        update(c, m, id);
    }

    static void refresh(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, DwWidget.class));
            for (int id : ids) update(c, m, id);
        } catch (Exception ignored) { }
    }

    private static void update(Context c, AppWidgetManager m, int id) {
        try {
            Bundle o = m.getAppWidgetOptions(id);
            boolean land = c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
            int wdp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int hdp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (wdp < 120) wdp = 250;
            if (hdp < 60) hdp = 110;
            float d = c.getResources().getDisplayMetrics().density;
            float scale = Math.min(1f, (float) Math.sqrt(900_000f / (wdp * d * hdp * d)));
            int w = Math.max(200, Math.round(wdp * d * scale));
            int h = Math.max(100, Math.round(hdp * d * scale));

            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dw_widget);
            rv.setImageViewBitmap(R.id.widget_img, render(c, w, h));
            Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            rv.setOnClickPendingIntent(R.id.widget_root,
                    PendingIntent.getActivity(c, 7, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            m.updateAppWidget(id, rv);
        } catch (Exception ignored) { }
    }

    // ---------- الرسم ----------
    private static Paint paint() { return new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG); }

    private static void text(Canvas cv, String s, float x, float y, float size, int color, Typeface tf, Paint.Align al) {
        Paint t = paint();
        t.setTypeface(tf);
        t.setTextSize(size);
        t.setColor(color);
        t.setTextAlign(al);
        cv.drawText(s, x, y, t);
    }

    private static int alpha(int color, int a) { return (color & 0x00FFFFFF) | (a << 24); }

    static Bitmap render(Context c, int w, int h) {
        Typeface bold = ResourcesCompat.getFont(c, R.font.aj_bold);
        Typeface reg = ResourcesCompat.getFont(c, R.font.aj_regular);
        if (bold == null) bold = Typeface.DEFAULT_BOLD;
        if (reg == null) reg = Typeface.DEFAULT;

        SharedPreferences sp = sp(c);
        int[] n = new int[4];
        int total = 0;
        for (int k = 0; k < 4; k++) { n[k] = sp.getInt("n_" + KINDS[k], 0); total += n[k]; }
        long last = sp.getLong("last", 0);

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = Math.min(w / 320f, h / 150f);
        RectF full = new RectF(0, 0, w, h);
        Paint p = paint();

        // خلفية كحلية متدرّجة + توهّج ذهبي وأزرق
        p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF22388F, 0xFF121E52, 0xFF0A112B}, new float[]{0f, .55f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(new RadialGradient(w * .92f, h * .05f, h * 1.05f, 0x55F5A83A, 0x00F5A83A, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(new RadialGradient(w * .08f, h * 1.0f, h * 1.1f, 0x403E6BFF, 0x003E6BFF, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(null);

        float m = 14 * u;

        // ----- الرأس: اللوجو يمينًا + حالة يسارًا -----
        Bitmap logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_logo);
        if (logo != null) {
            float lh = 33 * u, lw = lh * logo.getWidth() / logo.getHeight();
            Paint lp = paint();
            lp.setFilterBitmap(true);
            cv.drawBitmap(logo, null, new RectF(w - m - lw, 13 * u, w - m, 13 * u + lh), lp);
            logo.recycle();
        }
        boolean has = total > 0;
        int chipColor = has ? 0xFFF5A83A : 0xFF2FD39A;
        String chip = has ? "تنبيهات جديدة" : "لا جديد";
        Paint mp = paint();
        mp.setTypeface(bold);
        mp.setTextSize(11.5f * u);
        float cw = mp.measureText(chip) + 34 * u, ch = 24 * u, cy0 = 18 * u;
        RectF chipR = new RectF(m, cy0, m + cw, cy0 + ch);
        p.setStyle(Paint.Style.FILL);
        p.setColor(alpha(chipColor, 0x2E));
        cv.drawRoundRect(chipR, ch / 2, ch / 2, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.1f * u);
        p.setColor(alpha(chipColor, 0x88));
        cv.drawRoundRect(chipR, ch / 2, ch / 2, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(chipColor);
        cv.drawCircle(chipR.right - 12 * u, cy0 + ch / 2, 3.6f * u, p);
        text(cv, chip, chipR.right - 21 * u, cy0 + ch / 2 + 4.2f * u, 11.5f * u, 0xFFFFFFFF, bold, Paint.Align.RIGHT);

        // ----- أربع بطاقات (من اليمين لليسار) -----
        float top = 58 * u, bottom = h - 24 * u, gap = 8 * u;
        float tw = (w - 2 * m - 3 * gap) / 4f, th = bottom - top;
        for (int k = 0; k < 4; k++) {
            float right = w - m - k * (tw + gap), left = right - tw;
            RectF t = new RectF(left, top, right, bottom);
            boolean on = n[k] > 0;
            int col = COLORS[k];
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);
            if (on) {
                p.setShader(new LinearGradient(0, top, 0, bottom, alpha(col, 0x44), alpha(col, 0x14), Shader.TileMode.CLAMP));
            } else {
                p.setColor(0x18FFFFFF);
            }
            cv.drawRoundRect(t, 16 * u, 16 * u, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth((on ? 1.6f : 1f) * u);
            p.setColor(on ? alpha(col, 0xCC) : 0x22FFFFFF);
            cv.drawRoundRect(t, 16 * u, 16 * u, p);
            p.setStyle(Paint.Style.FILL);

            float cx = (left + right) / 2f;
            icon(cv, k, cx, top + th * .27f, 17 * u, on ? col : 0x88FFFFFF);
            String num = n[k] > 9 ? "9+" : String.valueOf(n[k]);
            text(cv, num, cx, top + th * .66f, 25 * u, on ? 0xFFFFFFFF : 0x77FFFFFF, bold, Paint.Align.CENTER);
            text(cv, LABELS[k], cx, bottom - 8 * u, 10f * u, on ? 0xFFFFFFFF : 0xAAFFFFFF, reg, Paint.Align.CENTER);
        }

        // ----- التذييل -----
        float fy = h - 8 * u;
        text(cv, "اضغط لفتح اللوحة", w - m, fy, 9.5f * u, 0x99FFFFFF, reg, Paint.Align.RIGHT);
        if (last > 0 && has) {
            String tm = new SimpleDateFormat("HH:mm", Locale.ENGLISH).format(new Date(last));
            text(cv, tm, m, fy, 9.5f * u, 0xFFF5A83A, bold, Paint.Align.LEFT);
        }

        // حواف دائرية ناعمة + إطار رفيع
        Paint mask = paint();
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        mask.setColor(0xFF000000);
        cv.drawRoundRect(full, 28 * u, 28 * u, mask);
        Paint bd = paint();
        bd.setStyle(Paint.Style.STROKE);
        bd.setStrokeWidth(1.4f * u);
        bd.setColor(0x30FFFFFF);
        cv.drawRoundRect(new RectF(.7f * u, .7f * u, w - .7f * u, h - .7f * u), 28 * u, 28 * u, bd);
        return bmp;
    }

    private static void icon(Canvas cv, int k, float cx, float cy, float s, int col) {
        Paint p = paint();
        p.setColor(col);
        p.setStyle(Paint.Style.FILL);
        switch (k) {
            case 0: { // رسالة
                cv.drawRoundRect(new RectF(cx - s * .55f, cy - s * .45f, cx + s * .55f, cy + s * .22f), s * .22f, s * .22f, p);
                Path t = new Path();
                t.moveTo(cx - s * .28f, cy + s * .15f);
                t.lineTo(cx - s * .38f, cy + s * .55f);
                t.lineTo(cx + s * .05f, cy + s * .15f);
                t.close();
                cv.drawPath(t, p);
                break;
            }
            case 1: { // عملة
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(s * .16f);
                cv.drawCircle(cx, cy, s * .46f, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, s * .16f, p);
                break;
            }
            case 2: { // مجموعة
                int back = alpha(col, 0x88);
                Paint b = paint();
                b.setColor(back);
                cv.drawCircle(cx + s * .3f, cy - s * .18f, s * .2f, b);
                cv.drawArc(new RectF(cx + s * .0f, cy + s * .08f, cx + s * .6f, cy + s * .66f), 180, 180, true, b);
                cv.drawCircle(cx - s * .22f, cy - s * .12f, s * .24f, p);
                cv.drawArc(new RectF(cx - s * .6f, cy + s * .16f, cx + s * .16f, cy + s * .8f), 180, 180, true, p);
                break;
            }
            default: { // طالب جديد
                cv.drawCircle(cx - s * .08f, cy - s * .18f, s * .24f, p);
                cv.drawArc(new RectF(cx - s * .5f, cy + s * .1f, cx + s * .34f, cy + s * .78f), 180, 180, true, p);
                p.setStrokeWidth(s * .13f);
                p.setStrokeCap(Paint.Cap.ROUND);
                cv.drawLine(cx + s * .5f, cy - s * .38f, cx + s * .5f, cy - s * .02f, p);
                cv.drawLine(cx + s * .32f, cy - s * .2f, cx + s * .68f, cy - s * .2f, p);
            }
        }
    }
}
