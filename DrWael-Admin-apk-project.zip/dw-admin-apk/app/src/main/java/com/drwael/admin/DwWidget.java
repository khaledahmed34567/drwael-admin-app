package com.drwael.admin;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.RemoteViews;

import androidx.core.content.res.ResourcesCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * ويدجت 4×2 «لوحة د. وائل»: عدّادات الدعم والمدفوعات والجروب والطلاب الجدد منذ آخر فتح للتطبيق.
 * يُرسم بنفس خط التطبيق (AJ) وبشعار Dr. Mohamed Wael، وكل بطاقة تفتح تبويبها مباشرة.
 * لا يعرض أسماء ولا نصوص رسائل (خصوصية).
 */
public class DwWidget extends AppWidgetProvider {
    static final String[] KINDS = {"support", "pay", "group", "signup"};
    static final String[] TABS = {"support", "pay", "group", "users"};
    static final String[] LABELS = {"الدعم", "المدفوعات", "الجروب", "طلاب جدد"};
    static final int[] COLORS = {0xFFFFB547, 0xFF3DDC97, 0xFF7CC4FF, 0xFFC9A7FF};
    static final int RED = 0xFFD12C33;

    // ---------- المخزن ----------
    static SharedPreferences sp(Context c) { return c.getSharedPreferences("dw_widget", Context.MODE_PRIVATE); }

    static void bump(Context c, String kind) {
        for (String k : KINDS) {
            if (k.equals(kind)) {
                SharedPreferences p = sp(c);
                p.edit().putInt("n_" + k, p.getInt("n_" + k, 0) + 1).putLong("last", System.currentTimeMillis()).apply();
                refresh(c);
                return;
            }
        }
    }

    static void clear(Context c) {
        SharedPreferences p = sp(c);
        boolean any = false;
        SharedPreferences.Editor e = p.edit();
        for (String k : KINDS) if (p.getInt("n_" + k, 0) != 0) { e.remove("n_" + k); any = true; }
        e.apply();
        if (any) refresh(c);
    }

    // ---------- الاستقبال ----------
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c, m, id); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { update(c, m, id); }

    static void refresh(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            for (int id : m.getAppWidgetIds(new ComponentName(c, DwWidget.class))) update(c, m, id);
            for (int id : m.getAppWidgetIds(new ComponentName(c, DwWidgetMini.class))) DwWidgetMini.update(c, m, id);
        } catch (Exception ignored) { }
    }

    /** مقاس الويدجت بالبكسل (محدود الذاكرة) من خيارات اللانشر. */
    static int[] sizePx(Context c, AppWidgetManager m, int id, int defW, int defH) {
        Bundle o = m.getAppWidgetOptions(id);
        boolean land = c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        int wdp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hdp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wdp < 60) wdp = defW;
        if (hdp < 40) hdp = defH;
        float d = c.getResources().getDisplayMetrics().density;
        float scale = Math.min(1f, (float) Math.sqrt(900_000f / (wdp * d * hdp * d)));
        return new int[]{Math.max(160, Math.round(wdp * d * scale)), Math.max(100, Math.round(hdp * d * scale))};
    }

    static PendingIntent open(Context c, int code, String tab) {
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (tab != null) { i.setAction("dw.open." + tab); i.putExtra("dw_tab", tab); }
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void update(Context c, AppWidgetManager m, int id) {
        try {
            int[] sz = sizePx(c, m, id, 250, 110);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dw_widget);
            rv.setImageViewBitmap(R.id.widget_img, render(c, sz[0], sz[1]));
            rv.setOnClickPendingIntent(R.id.widget_root, open(c, 7, null));
            // بطاقات من اليسار لليمين: طلاب جدد، الجروب، المدفوعات، الدعم
            int[] ids = {R.id.tile3, R.id.tile2, R.id.tile1, R.id.tile0};
            for (int k = 0; k < 4; k++) rv.setOnClickPendingIntent(ids[3 - k], open(c, 10 + k, TABS[k]));
            m.updateAppWidget(id, rv);
        } catch (Exception ignored) { }
    }

    // ---------- أدوات الرسم ----------
    static Paint paint() { return new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG); }

    static void text(Canvas cv, String s, float x, float y, float size, int color, Typeface tf, Paint.Align al) {
        Paint t = paint();
        t.setTypeface(tf);
        t.setTextSize(size);
        t.setColor(color);
        t.setTextAlign(al);
        cv.drawText(s, x, y, t);
    }

    static int alpha(int color, int a) { return (color & 0x00FFFFFF) | (a << 24); }

    static Typeface bold(Context c) { Typeface t = ResourcesCompat.getFont(c, R.font.aj_bold); return t != null ? t : Typeface.DEFAULT_BOLD; }
    static Typeface reg(Context c) { Typeface t = ResourcesCompat.getFont(c, R.font.aj_regular); return t != null ? t : Typeface.DEFAULT; }

    /** خلفية العلامة: نبيذي داكن + توهّج أحمر البراند وذهبي خفيف. */
    static void background(Canvas cv, int w, int h) {
        Paint p = paint();
        RectF full = new RectF(0, 0, w, h);
        p.setShader(new LinearGradient(0, 0, w * .8f, h, new int[]{0xFF3A0D13, 0xFF1C0A0D, 0xFF12060A}, new float[]{0f, .55f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(new RadialGradient(w * .96f, h * .02f, Math.max(w, h) * .75f, 0x99D12C33, 0x00D12C33, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(new RadialGradient(w * .04f, h * 1.02f, Math.max(w, h) * .6f, 0x33FFB547, 0x00FFB547, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
    }

    /** قصّ الحواف الدائرية بنعومة + إطار رفيع. */
    static void roundOff(Canvas cv, int w, int h, float r, float u) {
        Paint mask = paint();
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        mask.setColor(0xFF000000);
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, mask);
        Paint bd = paint();
        bd.setStyle(Paint.Style.STROKE);
        bd.setStrokeWidth(1.3f * u);
        bd.setColor(0x33FFFFFF);
        cv.drawRoundRect(new RectF(.7f * u, .7f * u, w - .7f * u, h - .7f * u), r, r, bd);
    }

    // ---------- الرسم: 4×2 ----------
    static Bitmap render(Context c, int w, int h) {
        Typeface bold = bold(c), reg = reg(c);
        SharedPreferences sp = sp(c);
        int[] n = new int[4];
        int total = 0;
        for (int k = 0; k < 4; k++) { n[k] = sp.getInt("n_" + KINDS[k], 0); total += n[k]; }
        long last = sp.getLong("last", 0);

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = Math.min(w / 320f, h / 150f);
        Paint p = paint();
        background(cv, w, h);

        float m = .045f * w;

        // ----- الرأس: الشعار يسارًا + حالة يمينًا -----
        Bitmap logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_logo);
        if (logo != null) {
            float lh = 26 * u, lw = lh * logo.getWidth() / logo.getHeight();
            Paint lp = paint();
            lp.setFilterBitmap(true);
            cv.drawBitmap(logo, null, new RectF(m, 17 * u, m + lw, 17 * u + lh), lp);
            logo.recycle();
        }
        boolean has = total > 0;
        int chipColor = has ? 0xFFFFB547 : 0xFF3DDC97;
        String chip = has ? "تنبيهات جديدة" : "لا جديد";
        Paint mp = paint();
        mp.setTypeface(bold);
        mp.setTextSize(11.5f * u);
        float cw = mp.measureText(chip) + 34 * u, ch = 24 * u, cy0 = 16 * u;
        RectF chipR = new RectF(w - m - cw, cy0, w - m, cy0 + ch);
        p.setStyle(Paint.Style.FILL);
        p.setColor(alpha(chipColor, 0x2E));
        cv.drawRoundRect(chipR, ch / 2, ch / 2, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.1f * u);
        p.setColor(alpha(chipColor, 0x88));
        cv.drawRoundRect(chipR, ch / 2, ch / 2, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(chipColor);
        cv.drawCircle(chipR.right - 12 * u, cy0 + ch / 2, 3.6f * u, p);
        text(cv, chip, chipR.right - 21 * u, cy0 + ch / 2 + 4.2f * u, 11.5f * u, 0xFFFFFFFF, bold, Paint.Align.RIGHT);

        // ----- أربع بطاقات (من اليمين لليسار) — نفس هندسة طبقة اللمس في الـ XML -----
        float top = .387f * h, bottom = .84f * h, gap = .025f * w;
        float tw = (w - 2 * m - 3 * gap) / 4f, th = bottom - top;
        for (int k = 0; k < 4; k++) {
            float right = w - m - k * (tw + gap), left = right - tw;
            RectF t = new RectF(left, top, right, bottom);
            boolean on = n[k] > 0;
            int col = COLORS[k];
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);
            if (on) p.setShader(new LinearGradient(0, top, 0, bottom, alpha(col, 0x44), alpha(col, 0x14), Shader.TileMode.CLAMP));
            else p.setColor(0x18FFFFFF);
            cv.drawRoundRect(t, 16 * u, 16 * u, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth((on ? 1.6f : 1f) * u);
            p.setColor(on ? alpha(col, 0xCC) : 0x22FFFFFF);
            cv.drawRoundRect(t, 16 * u, 16 * u, p);
            p.setStyle(Paint.Style.FILL);

            float cx = (left + right) / 2f;
            icon(cv, k, cx, top + th * .27f, 17 * u, on ? col : 0x88FFFFFF);
            String num = n[k] > 9 ? "9+" : String.valueOf(n[k]);
            text(cv, num, cx, top + th * .66f, 25 * u, on ? 0xFFFFFFFF : 0x77FFFFFF, bold, Paint.Align.CENTER);
            text(cv, LABELS[k], cx, bottom - 8 * u, 10f * u, on ? 0xFFFFFFFF : 0xAAFFFFFF, reg, Paint.Align.CENTER);
        }

        // ----- التذييل -----
        float fy = h - 9 * u;
        text(cv, "اضغط بطاقة لفتح تبويبها", w - m, fy, 9.5f * u, 0x99FFFFFF, reg, Paint.Align.RIGHT);
        if (last > 0 && has) {
            String tm = new SimpleDateFormat("HH:mm", Locale.ENGLISH).format(new Date(last));
            text(cv, tm, m, fy, 9.5f * u, 0xFFFFB547, bold, Paint.Align.LEFT);
        }
        roundOff(cv, w, h, 28 * u, u);
        return bmp;
    }

    // ---------- الرسم: 2×2 (حلقة الإجمالي) ----------
    static Bitmap renderMini(Context c, int w, int h) {
        Typeface bold = bold(c), reg = reg(c);
        SharedPreferences sp = sp(c);
        int[] n = new int[4];
        int total = 0;
        for (int k = 0; k < 4; k++) { n[k] = sp.getInt("n_" + KINDS[k], 0); total += n[k]; }

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = Math.min(w, h) / 160f;
        Paint p = paint();
        background(cv, w, h);

        // علامة W أعلى اليسار + عنوان صغير أعلى اليمين
        Bitmap mark = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_mark);
        if (mark != null) {
            float mh = 17 * u, mw = mh * mark.getWidth() / mark.getHeight();
            Paint lp = paint();
            lp.setFilterBitmap(true);
            cv.drawBitmap(mark, null, new RectF(13 * u, 13 * u, 13 * u + mw, 13 * u + mh), lp);
            mark.recycle();
        }
        text(cv, "التنبيهات", w - 13 * u, 27 * u, 12 * u, 0xCCFFFFFF, bold, Paint.Align.RIGHT);

        // الحلقة
        float cx = w / 2f, cy = h * .53f, R = Math.min(w, h) * .27f, sw = 13 * u;
        RectF oval = new RectF(cx - R, cy - R, cx + R, cy + R);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setColor(0x22FFFFFF);
        cv.drawOval(oval, p);
        if (total > 0) {
            float start = -90f, gapDeg = 5f;
            int parts = 0;
            for (int k = 0; k < 4; k++) if (n[k] > 0) parts++;
            for (int k = 0; k < 4; k++) {
                if (n[k] == 0) continue;
                float sweep = 360f * n[k] / total;
                float g = parts > 1 ? gapDeg : 0f;
                p.setColor(COLORS[k]);
                cv.drawArc(oval, start + g / 2, Math.max(1f, sweep - g), false, p);
                start += sweep;
            }
            String num = total > 99 ? "99+" : String.valueOf(total);
            text(cv, num, cx, cy + 6 * u, (num.length() > 2 ? 26 : 32) * u, 0xFFFFFFFF, bold, Paint.Align.CENTER);
            text(cv, "جديد", cx, cy + 24 * u, 11 * u, 0xCCFFFFFF, reg, Paint.Align.CENTER);
        } else {
            p.setColor(0xFF3DDC97);
            cv.drawArc(oval, -90, 360, false, p);
            p.setStrokeWidth(5 * u);
            p.setStrokeCap(Paint.Cap.ROUND);
            Path ck = new Path();
            ck.moveTo(cx - 13 * u, cy - 6 * u);
            ck.lineTo(cx - 3 * u, cy + 4 * u);
            ck.lineTo(cx + 15 * u, cy - 18 * u);
            cv.drawPath(ck, p);
            text(cv, "لا جديد", cx, cy + 24 * u, 11 * u, 0xCCFFFFFF, reg, Paint.Align.CENTER);
        }

        // مفتاح الألوان: عدّاد صغير لكل نوع (من اليمين لليسار)
        p.setStyle(Paint.Style.FILL);
        float ly = h - 14 * u, step = w / 4.6f, x0 = w - w * .13f;
        for (int k = 0; k < 4; k++) {
            float x = x0 - k * step;
            p.setColor(n[k] > 0 ? COLORS[k] : 0x55FFFFFF);
            cv.drawCircle(x, ly - 4 * u, 3.8f * u, p);
            text(cv, String.valueOf(n[k]), x - 7 * u, ly, 11 * u, n[k] > 0 ? 0xFFFFFFFF : 0x88FFFFFF, bold, Paint.Align.RIGHT);
        }
        roundOff(cv, w, h, 26 * u, u);
        return bmp;
    }

    private static void icon(Canvas cv, int k, float cx, float cy, float s, int col) {
        Paint p = paint();
        p.setColor(col);
        p.setStyle(Paint.Style.FILL);
        switch (k) {
            case 0: { // رسالة
                cv.drawRoundRect(new RectF(cx - s * .55f, cy - s * .45f, cx + s * .55f, cy + s * .22f), s * .22f, s * .22f, p);
                Path t = new Path();
                t.moveTo(cx - s * .28f, cy + s * .15f);
                t.lineTo(cx - s * .38f, cy + s * .55f);
                t.lineTo(cx + s * .05f, cy + s * .15f);
                t.close();
                cv.drawPath(t, p);
                break;
            }
            case 1: { // عملة
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(s * .16f);
                cv.drawCircle(cx, cy, s * .46f, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, cy, s * .16f, p);
                break;
            }
            case 2: { // مجموعة
                Paint b = paint();
                b.setColor(alpha(col, 0x88));
                cv.drawCircle(cx + s * .3f, cy - s * .18f, s * .2f, b);
                cv.drawArc(new RectF(cx + s * .0f, cy + s * .08f, cx + s * .6f, cy + s * .66f), 180, 180, true, b);
                cv.drawCircle(cx - s * .22f, cy - s * .12f, s * .24f, p);
                cv.drawArc(new RectF(cx - s * .6f, cy + s * .16f, cx + s * .16f, cy + s * .8f), 180, 180, true, p);
                break;
            }
            default: { // طالب جديد
                cv.drawCircle(cx - s * .08f, cy - s * .18f, s * .24f, p);
                cv.drawArc(new RectF(cx - s * .5f, cy + s * .1f, cx + s * .34f, cy + s * .78f), 180, 180, true, p);
                p.setStrokeWidth(s * .13f);
                p.setStrokeCap(Paint.Cap.ROUND);
                cv.drawLine(cx + s * .5f, cy - s * .38f, cx + s * .5f, cy - s * .02f, p);
                cv.drawLine(cx + s * .32f, cy - s * .2f, cx + s * .68f, cy - s * .2f, p);
            }
        }
    }
}
