package com.drwael.admin;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.RemoteViews;

/** شريط اختصارات 4×1: أربع أزرار دائرية (الدعم/المدفوعات/الجروب/الطلاب) بعدّاد، كل زر يفتح تبويبه. */
public class DwWidgetBar extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c, m, id); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { update(c, m, id); }

    static void update(Context c, AppWidgetManager m, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dw_widget_bar);
        try {
            int[] sz = DwWidget.sizePx(c, m, id, 250, 56);
            Bitmap b;
            try { b = render(c, sz[0], sz[1]); } catch (Throwable t) { b = render(c, sz[0] / 2, sz[1] / 2); }
            rv.setImageViewBitmap(R.id.widget_img_bar, b);
        } catch (Throwable ignored) { }
        try {
            rv.setOnClickPendingIntent(R.id.widget_root_bar, DwWidget.open(c, 31, null));
            rv.setOnClickPendingIntent(R.id.bar_app, DwWidget.open(c, 31, null));
            int[] ids = {R.id.bar_t3, R.id.bar_t2, R.id.bar_t1, R.id.bar_t0};
            for (int k = 0; k < 4; k++) rv.setOnClickPendingIntent(ids[3 - k], DwWidget.open(c, 40 + k, DwWidget.TABS[k]));
            m.updateAppWidget(id, rv);
        } catch (Throwable ignored) { }
    }

    static Bitmap render(Context c, int w, int h) {
        Typeface bold = DwWidget.bold(c);
        SharedPreferences sp = DwWidget.sp(c);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = Math.min(h / 56f, w / 300f);
        DwWidget.background(cv, w, h);
        Paint p = DwWidget.paint();

        Bitmap mark = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_mark);
        if (mark != null) {
            float mh = h * .46f, mw = mh * mark.getWidth() / mark.getHeight();
            Paint lp = DwWidget.paint();
            lp.setFilterBitmap(true);
            float mx = w * .26f / 2f - mw / 2f;
            cv.drawBitmap(mark, null, new RectF(mx, (h - mh) / 2f, mx + mw, (h + mh) / 2f), lp);
            mark.recycle();
        }
        // خط فاصل رفيع
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x22FFFFFF);
        cv.drawRect(w * .255f, h * .22f, w * .255f + Math.max(1f, u), h * .78f, p);

        for (int i = 0; i < 4; i++) {
            int k = 3 - i; // من اليسار: طلاب جدد، جروب، مدفوعات، دعم
            int n = sp.getInt("n_" + DwWidget.KINDS[k], 0);
            int col = DwWidget.COLORS[k];
            float sx = (260 + i * 180 + 90) / 1000f * w, cy = h / 2f;
            float dia = Math.min(h * .68f, .17f * w), r = dia / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(n > 0 ? DwWidget.alpha(col, 0x38) : 0x16FFFFFF);
            cv.drawCircle(sx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * u);
            p.setColor(n > 0 ? DwWidget.alpha(col, 0xCC) : 0x30FFFFFF);
            cv.drawCircle(sx, cy, r, p);
            p.setStyle(Paint.Style.FILL);
            DwWidget.icon(cv, k, sx, cy - r * .06f, dia * .46f, n > 0 ? col : 0x99FFFFFF);
            if (n > 0) {
                float br = Math.max(r * .36f, 7 * u), bx = sx + r * .72f, by = cy - r * .72f;
                p.setColor(0xFF12060A);
                cv.drawCircle(bx, by, br + 2 * u, p);
                p.setColor(col);
                cv.drawCircle(bx, by, br, p);
                DwWidget.text(cv, n > 9 ? "9+" : String.valueOf(n), bx, by + br * .38f, br * 1.15f, 0xFF1C0A0D, bold, Paint.Align.CENTER);
            }
        }
        DwWidget.roundOff(cv, w, h, h / 2f, u);
        return bmp;
    }
}
