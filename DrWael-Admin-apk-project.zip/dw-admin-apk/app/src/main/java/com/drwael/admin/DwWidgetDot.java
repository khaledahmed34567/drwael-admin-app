package com.drwael.admin;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.widget.RemoteViews;

/** ويدجت 1×1 «زر اللوحة»: علامة W على أحمر البراند مع شارة إجمالي الجديد. */
public class DwWidgetDot extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c, m, id); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { update(c, m, id); }

    static void update(Context c, AppWidgetManager m, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dw_widget_dot);
        try {
            int[] sz = DwWidget.sizePx(c, m, id, 60, 60);
            int s = Math.max(120, Math.min(sz[0], sz[1]));
            Bitmap b;
            try { b = render(c, s); } catch (Throwable t) { b = render(c, s / 2); }
            rv.setImageViewBitmap(R.id.widget_img_dot, b);
        } catch (Throwable ignored) { }
        try {
            rv.setOnClickPendingIntent(R.id.widget_root_dot, DwWidget.open(c, 71, null));
            m.updateAppWidget(id, rv);
        } catch (Throwable ignored) { }
    }

    static Bitmap render(Context c, int s) {
        SharedPreferences sp = DwWidget.sp(c);
        int total = 0;
        for (String k : DwWidget.KINDS) total += sp.getInt("n_" + k, 0);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = s / 80f;
        Paint p = DwWidget.paint();
        p.setShader(new LinearGradient(0, 0, s, s, 0xFFE0353C, 0xFF8E151C, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, s, s, p);
        p.setShader(new RadialGradient(s * .85f, s * .05f, s * .8f, 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, s, s, p);
        p.setShader(null);
        Bitmap mark = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_mark);
        if (mark != null) {
            float mw = s * .52f, mh = mw * mark.getHeight() / mark.getWidth();
            Paint lp = DwWidget.paint();
            lp.setFilterBitmap(true);
            cv.drawBitmap(mark, null, new RectF((s - mw) / 2f, (s - mh) / 2f, (s + mw) / 2f, (s + mh) / 2f), lp);
            mark.recycle();
        }
        if (total > 0) {
            float r = 13 * u, bx = s - 21 * u, by = 21 * u;
            p.setColor(0xFFFFFFFF);
            cv.drawCircle(bx, by, r + 2 * u, p);
            p.setColor(0xFF12060A);
            cv.drawCircle(bx, by, r, p);
            DwWidget.text(cv, total > 99 ? "99+" : String.valueOf(total), bx, by + r * .38f, r * (total > 99 ? .95f : 1.2f), 0xFFFFFFFF, DwWidget.bold(c), Paint.Align.CENTER);
        }
        DwWidget.roundOff(cv, s, s, 22 * u, u);
        return bmp;
    }
}
