package com.drwael.admin;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.RemoteViews;

/** «آخر النشاط» 4×2: آخر 3 أحداث (نوع + وقت، بلا أسماء) وكل صف يفتح تبويبه. */
public class DwWidgetFeed extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c, m, id); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { update(c, m, id); }

    static void update(Context c, AppWidgetManager m, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dw_widget_feed);
        try {
            int[] sz = DwWidget.sizePx(c, m, id, 250, 110);
            Bitmap b;
            try { b = render(c, sz[0], sz[1]); } catch (Throwable t) { b = render(c, sz[0] / 2, sz[1] / 2); }
            rv.setImageViewBitmap(R.id.widget_img_feed, b);
        } catch (Throwable ignored) { }
        try {
            rv.setOnClickPendingIntent(R.id.widget_root_feed, DwWidget.open(c, 51, null));
            long[][] log = DwWidget.log(c);
            int[] rows = {R.id.feed_r0, R.id.feed_r1, R.id.feed_r2};
            for (int i = 0; i < 3; i++) {
                String tab = i < log.length ? DwWidget.LOG_TABS[(int) log[i][0]] : null;
                rv.setOnClickPendingIntent(rows[i], DwWidget.open(c, 60 + i, tab));
            }
            m.updateAppWidget(id, rv);
        } catch (Throwable ignored) { }
    }

    static Bitmap render(Context c, int w, int h) {
        Typeface bold = DwWidget.bold(c), reg = DwWidget.reg(c);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = Math.min(w / 320f, h / 150f);
        DwWidget.background(cv, w, h);
        Paint p = DwWidget.paint();
        float m = .045f * w;

        Bitmap logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_logo);
        if (logo != null) {
            float lh = 22 * u, lw = lh * logo.getWidth() / logo.getHeight();
            Paint lp = DwWidget.paint();
            lp.setFilterBitmap(true);
            cv.drawBitmap(logo, null, new RectF(m, .075f * h, m + lw, .075f * h + lh), lp);
            logo.recycle();
        }
        DwWidget.text(cv, "آخر النشاط", w - m, .075f * h + 17 * u, 13 * u, 0xFFFFFFFF, bold, Paint.Align.RIGHT);

        long[][] log = DwWidget.log(c);
        float top = .30f * h, rh = .23f * h, gap = .018f * h;
        for (int i = 0; i < 3; i++) {
            float y0 = top + i * rh + gap / 2f, y1 = top + (i + 1) * rh - gap / 2f;
            RectF row = new RectF(m, y0, w - m, y1);
            boolean has = i < log.length;
            int k = has ? (int) log[i][0] : 0, col = has ? DwWidget.LOG_COLORS[k] : 0x66FFFFFF;
            p.setStyle(Paint.Style.FILL);
            p.setColor(has ? 0x1CFFFFFF : 0x0DFFFFFF);
            cv.drawRoundRect(row, 14 * u, 14 * u, p);
            if (!has) continue;
            float cy = (y0 + y1) / 2f, ir = (y1 - y0) * .34f, icx = w - m - (y1 - y0) * .5f;
            p.setColor(DwWidget.alpha(col, 0x38));
            cv.drawCircle(icx, cy, ir, p);
            DwWidget.icon(cv, k, icx, cy - ir * .06f, ir * 1.05f, col);
            // ذيل ملوّن رفيع
            p.setColor(col);
            cv.drawRoundRect(new RectF(w - m - 3.2f * u, y0 + (y1 - y0) * .24f, w - m, y1 - (y1 - y0) * .24f), 2 * u, 2 * u, p);
            DwWidget.text(cv, DwWidget.LOG_LABELS[k], icx - ir - 9 * u, cy + 4.6f * u, 12.5f * u, 0xFFFFFFFF, bold, Paint.Align.RIGHT);
            DwWidget.text(cv, DwWidget.when(log[i][1]), m + 12 * u, cy + 4.2f * u, 11 * u, DwWidget.alpha(col, 0xFF), bold, Paint.Align.LEFT);
        }
        if (log.length == 0) {
            DwWidget.text(cv, "لا نشاط بعد", w / 2f, top + rh * 1.25f, 15 * u, 0xCCFFFFFF, bold, Paint.Align.CENTER);
            DwWidget.text(cv, "ستظهر هنا آخر الإشعارات", w / 2f, top + rh * 1.25f + 20 * u, 11 * u, 0x88FFFFFF, reg, Paint.Align.CENTER);
        }
        DwWidget.roundOff(cv, w, h, 28 * u, u);
        return bmp;
    }
}
