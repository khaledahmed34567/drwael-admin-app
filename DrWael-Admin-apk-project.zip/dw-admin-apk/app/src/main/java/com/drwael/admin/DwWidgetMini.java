package com.drwael.admin;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;
import android.widget.RemoteViews;

/** ويدجت 2×2 «حلقة التنبيهات»: إجمالي الجديد بحلقة ملوّنة حسب النوع. الضغط يفتح اللوحة. */
public class DwWidgetMini extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c, m, id); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { update(c, m, id); }

    static void update(Context c, AppWidgetManager m, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dw_widget_mini);
        try {
            int[] sz = DwWidget.sizePx(c, m, id, 110, 110);
            android.graphics.Bitmap b;
            try { b = DwWidget.renderMini(c, sz[0], sz[1]); } catch (Throwable t) { b = DwWidget.renderMini(c, sz[0] / 2, sz[1] / 2); }
            rv.setImageViewBitmap(R.id.widget_img_mini, b);
        } catch (Throwable ignored) { }
        try {
            rv.setOnClickPendingIntent(R.id.widget_root_mini, DwWidget.open(c, 21, null));
            m.updateAppWidget(id, rv);
        } catch (Throwable ignored) { }
    }
}
