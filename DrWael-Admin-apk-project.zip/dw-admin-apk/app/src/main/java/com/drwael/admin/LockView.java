package com.drwael.admin;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** شاشة «التطبيق مقفل»: خلفية البراند + شعار + زر بصمة نابض + رسالة خطأ عند الفشل. تُرسم كلها بالكانفاس. */
public class LockView extends View {
    public interface OnUnlock { void run(); }

    private OnUnlock listener;
    private float phase = 0f;
    private ValueAnimator anim;
    private Bitmap logo;
    private String error = null;
    private boolean busy = false;
    private float cx, cy, R, btnL, btnT, btnR, btnB;
    private final Typeface bold, reg;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);

    public LockView(Context c) {
        super(c);
        bold = DwWidget.bold(c);
        reg = DwWidget.reg(c);
        logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.dw_logo);
        setFilterTouchesWhenObscured(true);
        setClickable(true);
        setFocusable(true);
        setContentDescription("التطبيق مقفل. اضغط لفتحه بالبصمة أو الوجه");
    }

    public void setOnUnlock(OnUnlock l) { listener = l; }

    public void setError(String e) { error = e; busy = false; invalidate(); }

    public void setBusy(boolean b) { busy = b; if (b) error = null; invalidate(); }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(2600);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> { phase = (float) a.getAnimatedValue(); invalidate(); });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) {
            float x = e.getX(), y = e.getY();
            boolean onCircle = Math.hypot(x - cx, y - cy) <= R * 1.25f;
            boolean onBtn = x >= btnL && x <= btnR && y >= btnT - 20 && y <= btnB + 20;
            if ((onCircle || onBtn) && !busy && listener != null) { performClick(); listener.run(); }
        }
        return true;
    }

    @Override
    public boolean performClick() { return super.performClick(); }

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        RectF full = new RectF(0, 0, w, h);

        // خلفية
        p.setShader(new LinearGradient(0, 0, w * .8f, h, new int[]{0xFF3A0D13, 0xFF1C0A0D, 0xFF0F0508}, new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(new RadialGradient(w * .95f, h * .02f, Math.max(w, h) * .7f, 0xA0D12C33, 0x00D12C33, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(new RadialGradient(w * .05f, h * 1.0f, Math.max(w, h) * .55f, 0x40FFB547, 0x00FFB547, Shader.TileMode.CLAMP));
        cv.drawRect(full, p);
        p.setShader(null);

        // الشعار
        if (logo != null) {
            float lw = Math.min(w * .62f, 300 * d), lh = lw * logo.getHeight() / logo.getWidth();
            Paint lp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            float ly = h * .11f;
            cv.drawBitmap(logo, null, new RectF((w - lw) / 2f, ly, (w + lw) / 2f, ly + lh), lp);
        }

        // دائرة البصمة + حلقات نابضة
        cx = w / 2f;
        cy = h * .42f;
        R = Math.min(w * .22f, 92 * d);
        p.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 3; i++) {
            float t = (phase + i / 3f) % 1f;
            float rr = R * (1.05f + t * 0.95f);
            int a = (int) (110 * (1f - t) * (1f - t));
            p.setColor((a << 24) | 0x00FF6A72);
            p.setStrokeWidth(2.2f * d);
            cv.drawCircle(cx, cy, rr, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(cx - R, cy - R, cx + R, cy + R, 0xFFE0353C, 0xFF8E151C, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, R, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setColor(0x66FFFFFF);
        cv.drawCircle(cx, cy, R, p);
        p.setColor(0x22FFFFFF);
        cv.drawCircle(cx, cy, R * .86f, p);
        fingerprint(cv, cx, cy, R * 1.25f, d, busy ? 0xFFFFD08A : 0xFFFFFFFF);

        // النصوص
        float ty = cy + R + 54 * d;
        DwWidget.text(cv, "التطبيق مقفل", cx, ty, 27 * d, 0xFFFFFFFF, bold, Paint.Align.CENTER);
        DwWidget.text(cv, "افتحه بالبصمة أو الوجه للمتابعة", cx, ty + 30 * d, 15 * d, 0xB3FFFFFF, reg, Paint.Align.CENTER);

        // رسالة الخطأ
        if (error != null) DwWidget.text(cv, error, cx, ty + 62 * d, 14 * d, 0xFFFFB547, bold, Paint.Align.CENTER);

        // زر الفتح
        float bw = Math.min(w * .72f, 320 * d), bh = 56 * d;
        btnL = (w - bw) / 2f;
        btnR = btnL + bw;
        btnT = Math.min(h - 120 * d, ty + 86 * d);
        btnB = btnT + bh;
        RectF br = new RectF(btnL, btnT, btnR, btnB);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(btnL, btnT, btnL, btnB, 0xFFFFFFFF, 0xFFFFE3C7, Shader.TileMode.CLAMP));
        cv.drawRoundRect(br, bh / 2, bh / 2, p);
        p.setShader(null);
        DwWidget.text(cv, busy ? "جارٍ التحقق…" : "فتح بالبصمة", cx, btnT + bh / 2 + 6 * d, 18 * d, 0xFF8E151C, bold, Paint.Align.CENTER);

        // التذييل
        DwWidget.text(cv, "لوحة د. وائل · محمي", cx, h - 34 * d, 12.5f * d, 0x80FFFFFF, reg, Paint.Align.CENTER);
    }

    private void fingerprint(Canvas cv, float cx, float cy, float s, float d, int col) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(col);
        p.setStrokeWidth(2.6f * d);
        for (int i = 0; i < 5; i++) {
            float r = s * (0.10f + 0.095f * i) * 0.62f * 2f;
            RectF o = new RectF(cx - r, cy - r * 1.15f, cx + r, cy + r * 1.15f);
            cv.drawArc(o, 172 + (i % 2) * 8, 196 - (i % 2) * 16, false, p);
        }
        for (int i = 1; i <= 3; i += 2) {
            float r = s * (0.10f + 0.095f * i) * 0.62f * 2f;
            RectF o = new RectF(cx - r, cy - r * 1.15f, cx + r, cy + r * 1.15f);
            cv.drawArc(o, 20, 130, false, p);
        }
        cv.drawLine(cx, cy - s * 0.02f, cx, cy + s * 0.2f, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}
