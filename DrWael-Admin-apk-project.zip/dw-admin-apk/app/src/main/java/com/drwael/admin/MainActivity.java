package com.drwael.admin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.function.Consumer;

public class MainActivity extends AppCompatActivity {
    private static final String HOST = "appassets.androidplatform.net";
    static volatile boolean foreground = false;

    /** بعد كم من الوقت في الخلفية يُقفل التطبيق ويطلب البصمة/الوجه مجددًا. */
    private long lockMs() { int sec = getSharedPreferences("dw_state", MODE_PRIVATE).getInt("lock_sec", 60); return sec < 0 ? Long.MAX_VALUE : sec * 1000L; }

    private WebView web;
    private FrameLayout root;
    private LockView cover;
    private long stoppedAt = 0;
    private boolean external = false; // فتح شاشة خارجية (ملفات/كاميرا/تثبيت) لا يُعدّ خروجًا من التطبيق
    private boolean locked = false;
    private String pendingTab = null;      // تبويب مطلوب من ويدجت أو إشعار
    private boolean pageReady = false;
    private volatile boolean trusted = false; // الصفحة الحالية هي صفحة التطبيق نفسها
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;
    private ActivityResultLauncher<Intent> picker;
    private ActivityResultLauncher<String> notifPerm;
    private ActivityResultLauncher<String> camPerm;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        // منع لقطات الشاشة وتسجيل الشاشة وظهور المحتوى في قائمة التطبيقات الأخيرة
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(false);

        Notifier.createChannels(this);

        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            external = false;
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData()));
                fileCb = null;
            }
        });
        notifPerm = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
            external = false;
            if (!ok) openNotifSettingsOnce();
            startKeepAlive();
        });
        camPerm = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
            external = false;
            PermissionRequest p = pendingPerm;
            pendingPerm = null;
            if (p == null) return;
            if (ok) p.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); else p.deny();
        });

        web = new WebView(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1C0A0D);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        WebView.setWebContentsDebuggingEnabled(false);
        web.setFilterTouchesWhenObscured(true); // يمنع النقر الخادع من تطبيقات تعلو الشاشة
        web.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setSaveFormData(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSafeBrowsingEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        web.setBackgroundColor(0xFF1C0A0D);
        // يُبقي محرّك الصفحة نشطًا بالخلفية ليصل الاستماع للرسائل/المدفوعات
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                trusted = isOwnPage(url);
                super.onPageStarted(v, url, icon);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                trusted = isOwnPage(url);
                pageReady = true;
                deliverTab();
                super.onPageFinished(v, url);
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                // انهيار محرّك الصفحة: أعد تشغيل الشاشة بدل إغلاق التطبيق
                runOnUiThread(() -> recreate());
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String sc = u.getScheme();
                if ("tel".equals(sc)) {
                    try { external = true; startActivity(new Intent(Intent.ACTION_DIAL, u)); } catch (Exception ignored) { }
                } else if ("https".equals(sc)) {
                    try { external = true; startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult r) {
                showJsDialog(message, false, r);
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, JsResult r) {
                showJsDialog(message, true, r);
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    external = true;
                    picker.launch(p.createIntent());
                } catch (Exception e) {
                    fileCb = null;
                    external = false;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean cam = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
                    if (!cam || !HOST.equals(req.getOrigin().getHost())) { req.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingPerm = req;
                        external = true;
                        camPerm.launch(Manifest.permission.CAMERA);
                    }
                });
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("https://" + HOST + "/assets/admin.html");
        handleTabIntent(getIntent());
        DwWidget.refresh(this);

        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            external = true;
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            startKeepAlive();
        }
    }

    private void startKeepAlive() {
        try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); } catch (Exception ignored) { }
        askIgnoreBatteryOnce();
    }

    private android.content.SharedPreferences prefs() { return getSharedPreferences("dw_state", MODE_PRIVATE); }

    /** تعطيل «توفير البطارية» للتطبيق (مرة واحدة) كي لا يُوقف النظام الاستماع بالخلفية. */
    private void askIgnoreBatteryOnce() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            if (prefs().getBoolean("asked_batt", false)) return;
            prefs().edit().putBoolean("asked_batt", true).apply();
            external = true;
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    /** لو رُفض إذن الإشعارات: افتح إعدادات إشعارات التطبيق مرة واحدة. */
    private void openNotifSettingsOnce() {
        try {
            if (prefs().getBoolean("asked_notif_settings", false)) return;
            prefs().edit().putBoolean("asked_notif_settings", true).apply();
            external = true;
            startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
        } catch (Exception ignored) { }
    }

    /** نافذة تأكيد/تنبيه بتصميم التطبيق بدل نافذة النظام الافتراضية (التي تعرض عنوان الصفحة). */
    private void showJsDialog(String message, boolean confirm, final JsResult r) {
        runOnUiThread(() -> {
            final float dp = getResources().getDisplayMetrics().density;
            final Dialog dlg = new Dialog(this);
            dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
            final boolean[] done = {false};

            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            box.setPadding((int) (22 * dp), (int) (26 * dp), (int) (22 * dp), (int) (18 * dp));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFFFFFFFF);
            bg.setCornerRadius(30 * dp);
            box.setBackground(bg);

            TextView ico = new TextView(this);
            ico.setText(confirm ? "؟" : "!");
            ico.setGravity(Gravity.CENTER);
            ico.setTextColor(0xFFFFFFFF);
            ico.setTextSize(26);
            ico.setTypeface(DwWidget.bold(this));
            GradientDrawable ib = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFD12C33, 0xFF7A1218});
            ib.setShape(GradientDrawable.OVAL);
            ico.setBackground(ib);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams((int) (58 * dp), (int) (58 * dp));
            ip.gravity = Gravity.CENTER_HORIZONTAL;
            box.addView(ico, ip);

            TextView title = new TextView(this);
            title.setText(confirm ? "تأكيد الإجراء" : "تنبيه");
            title.setTextSize(19);
            title.setTextColor(0xFF1A1416);
            title.setGravity(Gravity.CENTER);
            title.setTypeface(DwWidget.bold(this));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
            tp.topMargin = (int) (14 * dp);
            box.addView(title, tp);

            TextView msg = new TextView(this);
            msg.setText(message);
            msg.setTextSize(15);
            msg.setTextColor(0xFF5A4A4E);
            msg.setGravity(Gravity.CENTER);
            msg.setLineSpacing(0, 1.3f);
            msg.setTypeface(DwWidget.reg(this));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.topMargin = (int) (8 * dp);
            mp.bottomMargin = (int) (20 * dp);
            box.addView(msg, mp);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            TextView ok = dialogButton(confirm ? "متابعة" : "حسنًا", true, dp);
            ok.setOnClickListener(x -> { if (!done[0]) { done[0] = true; r.confirm(); } dlg.dismiss(); });
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, (int) (50 * dp), 1f);
            bp.setMargins((int) (5 * dp), 0, (int) (5 * dp), 0);
            row.addView(ok, bp);
            if (confirm) {
                TextView no = dialogButton("إلغاء", false, dp);
                no.setOnClickListener(x -> { if (!done[0]) { done[0] = true; r.cancel(); } dlg.dismiss(); });
                row.addView(no, bp);
            }
            box.addView(row, new LinearLayout.LayoutParams(-1, -2));

            dlg.setContentView(box);
            dlg.setOnCancelListener(x -> { if (!done[0]) { done[0] = true; r.cancel(); } });
            Window w = dlg.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88f), WindowManager.LayoutParams.WRAP_CONTENT);
                w.setGravity(Gravity.CENTER);
                w.setDimAmount(0.62f);
                w.addFlags(WindowManager.LayoutParams.FLAG_SECURE | WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
            dlg.show();
        });
    }

    private TextView dialogButton(String text, boolean primary, float dp) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(15.5f);
        b.setTypeface(DwWidget.bold(this));
        b.setTextColor(primary ? 0xFFFFFFFF : 0xFF4A3A3E);
        GradientDrawable g = primary
                ? new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF8E151C, 0xFFD12C33})
                : new GradientDrawable();
        if (!primary) g.setColor(0xFFF3EAEA);
        g.setCornerRadius(17 * dp);
        b.setBackground(g);
        return b;
    }

    private void handleTabIntent(Intent in) {
        if (in == null) return;
        String t = in.getStringExtra("dw_tab");
        if (t == null) return;
        in.removeExtra("dw_tab");
        switch (t) { case "support": case "pay": case "group": case "users": case "team": pendingTab = t; deliverTab(); break; default: break; }
    }

    private void deliverTab() {
        if (pendingTab == null || !pageReady || !trusted || web == null) return;
        final String t = pendingTab;
        pendingTab = null;
        web.evaluateJavascript("window.dwOpenTab&&dwOpenTab('" + t + "')", null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleTabIntent(intent);
    }

    private boolean isOwnPage(String url) {
        try { return url != null && "https".equals(Uri.parse(url).getScheme()) && HOST.equals(Uri.parse(url).getHost()); }
        catch (Exception e) { return false; }
    }

    @Override protected void onResume() { super.onResume(); foreground = true; DwWidget.clear(this); }
    @Override protected void onPause() { foreground = false; super.onPause(); }

    @Override
    protected void onStop() {
        super.onStop();
        if (!external && !locked) stoppedAt = SystemClock.elapsedRealtime();
        // لا توقف مؤقّتات الصفحة بالخلفية: الاستماع للإشعارات يعتمد عليها
        if (web != null) { web.onResume(); web.resumeTimers(); }
    }

    @Override
    protected void onStart() {
        super.onStart();
        boolean away = stoppedAt > 0 && SystemClock.elapsedRealtime() - stoppedAt > lockMs();
        stoppedAt = 0;
        external = false;
        if (away && !locked && SecureStore.get(this) != null) lockApp();
    }

    /** قفل تلقائي: يغطّي الشاشة ويطلب البصمة/الوجه عند العودة بعد غياب أكثر من دقيقة. */
    private void lockApp() {
        locked = true;
        if (cover == null) {
            cover = new LockView(this);
            cover.setOnUnlock(this::unlockApp);
            root.addView(cover, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
        cover.setError(null);
        cover.setVisibility(View.VISIBLE);
        cover.bringToFront();
        unlockApp();
    }

    private void unlockApp() {
        if (cover != null) cover.setBusy(true);
        biometric("فتح التطبيق", "لوحة د. وائل", r -> {
            if (!"fail".equals(r)) {
                locked = false;
                if (cover != null) cover.setVisibility(View.GONE);
            } else if (cover != null) {
                cover.setError("لم ينجح التحقق، حاول مرة أخرى");
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); }
        super.onDestroy();
    }

    private void reply(int id, boolean ok) {
        if (id == 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("ok", ok);
            final String js = "window.DWNative&&window.DWNative.onmessage&&window.DWNative.onmessage({data:" + JSONObject.quote(o.toString()) + "})";
            runOnUiThread(() -> web.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    /** استدعاء دالة داخل الصفحة: DWX.native.<fn>(<arg>) — arg يجب أن يكون JSON/JS صالحًا. */
    private void jsCall(final String fn, final String arg) {
        final String js = "(function(){var n=window.DWX&&window.DWX.native;if(n&&n." + fn + ")n." + fn + "(" + arg + ")})()";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private int bioAllowed() {
        return Build.VERSION.SDK_INT >= 30
                ? (BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
    }

    /** بصمة أو وجه (حسب ما فعّله المستخدم في الهاتف). النتيجة: "ok" / "fail" / "na" (لا توجد بصمة على الجهاز). */
    private void biometric(String title, String sub, final Consumer<String> done) {
        final int allowed = bioAllowed();
        if (BiometricManager.from(this).canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            done.accept("na");
            return;
        }
        BiometricPrompt.PromptInfo.Builder pb = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(sub)
                .setAllowedAuthenticators(allowed);
        if (Build.VERSION.SDK_INT < 30) pb.setNegativeButtonText("إلغاء");
        new BiometricPrompt(this, ContextCompat.getMainExecutor(this), new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { done.accept("ok"); }
            @Override public void onAuthenticationError(int code, CharSequence msg) { done.accept("fail"); }
        }).authenticate(pb.build());
    }

    private void authenticate(int id, String why) {
        biometric("تأكيد الهوية", why == null || why.isEmpty() ? "لوحة د. وائل" : why, r -> reply(id, !"fail".equals(r)));
    }

    private void save(int id, JSONObject m) {
        new Thread(() -> {
            try {
                String name = m.optString("name", "file").replaceAll("[\\\\/:*?\"<>|]", "_");
                String mime = m.optString("mime", "application/octet-stream");
                byte[] data = Base64.decode(m.optString("b64", ""), Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new RuntimeException("insert");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(data); }
                } else {
                    File d = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    try (FileOutputStream os = new FileOutputStream(new File(d, name))) { os.write(data); }
                }
                reply(id, true);
            } catch (Exception e) {
                reply(id, false);
            }
        }).start();
    }

    private final Updater.Listener updListener = new Updater.Listener() {
        @Override public void onUpdate(JSONObject o) { jsCall("onUpdate", o.toString()); }
        @Override public void onProgress(int pct) { jsCall("onProgress", String.valueOf(pct)); }
        @Override public void onDownloaded(File f) {
            runOnUiThread(() -> {
                try {
                    external = true;
                    Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(u, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    jsCall("onInstall", "true");
                } catch (Exception e) {
                    jsCall("onInstall", "false");
                }
            });
        }
        @Override public void onError(String m) { jsCall("onInstall", "false"); }
    };

    private class Bridge {
        @JavascriptInterface
        public void postMessage(String s) {
            if (!trusted) return;
            try {
                JSONObject m = new JSONObject(s);
                final int id = m.optInt("id");
                switch (m.optString("a")) {
                    case "auth": { final String why = m.optString("why"); runOnUiThread(() -> authenticate(id, why)); break; }
                    case "save": save(id, m); break;
                    case "notify":
                        if (!foreground) {
                            Notifier.show(MainActivity.this, m.optString("title"), m.optString("body"), m.optString("sound"), m.optString("kind"));
                            DwWidget.bump(MainActivity.this, m.optString("kind"));
                        }
                        break;
                    case "google": reply(id, false); break; // الدخول بجوجل غير مفعّل في التطبيق
                    default: reply(id, true);
                }
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public String getVersion() { return trusted ? Updater.localName(MainActivity.this) : ""; }
        @JavascriptInterface public boolean hasSecret() { return trusted && SecureStore.get(MainActivity.this) != null; }
        @JavascriptInterface public void saveSecret(String v) { if (trusted && v != null && !v.isEmpty()) SecureStore.put(MainActivity.this, v); }
        @JavascriptInterface public void clearSecret() { if (trusted) SecureStore.clear(MainActivity.this); }

        @JavascriptInterface public int getLockSec() { return trusted ? getSharedPreferences("dw_state", MODE_PRIVATE).getInt("lock_sec", 60) : 60; }
        @JavascriptInterface public void setLockSec(int sec) {
            if (!trusted) return;
            if (sec != 0 && sec != 30 && sec != 60 && sec != 300 && sec != -1) return;
            getSharedPreferences("dw_state", MODE_PRIVATE).edit().putInt("lock_sec", sec).apply();
        }
        @JavascriptInterface public void lockNow() { if (trusted) runOnUiThread(() -> { if (!locked) lockApp(); }); }
        @JavascriptInterface public void testNotify() {
            if (!trusted) return;
            Notifier.show(MainActivity.this, "اختبار الإشعارات", "إذا وصلك هذا الإشعار بالصوت فكل شيء يعمل", "chime", null);
        }

        /** تسجيل الخروج: يمسح الكاش والسجل وملفات تعريف الارتباط (يبقى الدخول بالبصمة محفوظًا في المخزن المشفّر). */
        @JavascriptInterface
        public void logout() {
            if (!trusted) return;
            runOnUiThread(() -> {
                try {
                    web.clearCache(true);
                    web.clearHistory();
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                } catch (Exception ignored) { }
            });
        }

        /** دخول بالبصمة/الوجه: يعيد الكود المحفوظ إلى الصفحة (أو null). */
        @JavascriptInterface
        public void unlock() {
            if (!trusted) return;
            runOnUiThread(() -> biometric("الدخول بالبصمة أو الوجه", "لوحة د. وائل", r -> {
                String code = "ok".equals(r) ? SecureStore.get(MainActivity.this) : null;
                jsCall("onUnlock", code == null ? "null" : JSONObject.quote(code));
            }));
        }

        /** تحقق بايومتري (وجه/بصمة) عند أول دخول. */
        @JavascriptInterface
        public void verifyBio() {
            if (!trusted) return;
            runOnUiThread(() -> biometric("تحقق من هويتك", "أول دخول على هذا الجهاز", r -> jsCall("onBio", JSONObject.quote(r))));
        }

        @JavascriptInterface public void checkUpdate() { if (trusted) Updater.check(MainActivity.this, updListener); }

        @JavascriptInterface
        public void installUpdate() {
            if (!trusted) return;
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                    try {
                        external = true;
                        startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) { }
                    jsCall("onInstall", "\"perm\"");
                    return;
                }
                Updater.download(MainActivity.this, updListener);
            });
        }
    }
}
