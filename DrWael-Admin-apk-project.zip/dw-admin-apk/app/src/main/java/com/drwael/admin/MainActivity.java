package com.drwael.admin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.function.Consumer;

public class MainActivity extends AppCompatActivity {
    private static final String HOST = "appassets.androidplatform.net";
    static volatile boolean foreground = false;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;
    private ActivityResultLauncher<Intent> picker;
    private ActivityResultLauncher<String> notifPerm;
    private ActivityResultLauncher<String> camPerm;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        // منع لقطات الشاشة وتسجيل الشاشة وظهور المحتوى في قائمة التطبيقات الأخيرة
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        super.onCreate(b);

        Notifier.createChannels(this);

        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData()));
                fileCb = null;
            }
        });
        notifPerm = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> startKeepAlive());
        camPerm = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
            PermissionRequest p = pendingPerm;
            pendingPerm = null;
            if (p == null) return;
            if (ok) p.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); else p.deny();
        });

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setSaveFormData(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        web.setBackgroundColor(0xFF0B1331);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                if ("https".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    picker.launch(p.createIntent());
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean cam = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
                    if (!cam || !HOST.equals(req.getOrigin().getHost())) { req.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingPerm = req;
                        camPerm.launch(Manifest.permission.CAMERA);
                    }
                });
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("https://" + HOST + "/assets/admin.html");

        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            startKeepAlive();
        }
    }

    private void startKeepAlive() {
        try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); } catch (Exception ignored) { }
    }

    @Override protected void onResume() { super.onResume(); foreground = true; }
    @Override protected void onPause() { foreground = false; super.onPause(); }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); }
        super.onDestroy();
    }

    private void reply(int id, boolean ok) {
        if (id == 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("ok", ok);
            final String js = "window.DWNative&&window.DWNative.onmessage&&window.DWNative.onmessage({data:" + JSONObject.quote(o.toString()) + "})";
            runOnUiThread(() -> web.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    /** استدعاء دالة داخل الصفحة: DWX.native.<fn>(<arg>) — arg يجب أن يكون JSON/JS صالحًا. */
    private void jsCall(final String fn, final String arg) {
        final String js = "(function(){var n=window.DWX&&window.DWX.native;if(n&&n." + fn + ")n." + fn + "(" + arg + ")})()";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private int bioAllowed() {
        return Build.VERSION.SDK_INT >= 30
                ? (BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
    }

    /** بصمة أو وجه (حسب ما فعّله المستخدم في الهاتف). النتيجة: "ok" / "fail" / "na" (لا توجد بصمة على الجهاز). */
    private void biometric(String title, String sub, final Consumer<String> done) {
        final int allowed = bioAllowed();
        if (BiometricManager.from(this).canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            done.accept("na");
            return;
        }
        BiometricPrompt.PromptInfo.Builder pb = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(sub)
                .setAllowedAuthenticators(allowed);
        if (Build.VERSION.SDK_INT < 30) pb.setNegativeButtonText("إلغاء");
        new BiometricPrompt(this, ContextCompat.getMainExecutor(this), new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { done.accept("ok"); }
            @Override public void onAuthenticationError(int code, CharSequence msg) { done.accept("fail"); }
        }).authenticate(pb.build());
    }

    private void authenticate(int id, String why) {
        biometric("تأكيد الهوية", why == null || why.isEmpty() ? "لوحة د. وائل" : why, r -> reply(id, !"fail".equals(r)));
    }

    private void save(int id, JSONObject m) {
        new Thread(() -> {
            try {
                String name = m.optString("name", "file").replaceAll("[\\\\/:*?\"<>|]", "_");
                String mime = m.optString("mime", "application/octet-stream");
                byte[] data = Base64.decode(m.optString("b64", ""), Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new RuntimeException("insert");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(data); }
                } else {
                    File d = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    try (FileOutputStream os = new FileOutputStream(new File(d, name))) { os.write(data); }
                }
                reply(id, true);
            } catch (Exception e) {
                reply(id, false);
            }
        }).start();
    }

    private final Updater.Listener updListener = new Updater.Listener() {
        @Override public void onUpdate(JSONObject o) { jsCall("onUpdate", o.toString()); }
        @Override public void onProgress(int pct) { jsCall("onProgress", String.valueOf(pct)); }
        @Override public void onDownloaded(File f) {
            runOnUiThread(() -> {
                try {
                    Uri u = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(u, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    jsCall("onInstall", "true");
                } catch (Exception e) {
                    jsCall("onInstall", "false");
                }
            });
        }
        @Override public void onError(String m) { jsCall("onInstall", "false"); }
    };

    private class Bridge {
        @JavascriptInterface
        public void postMessage(String s) {
            try {
                JSONObject m = new JSONObject(s);
                final int id = m.optInt("id");
                switch (m.optString("a")) {
                    case "auth": { final String why = m.optString("why"); runOnUiThread(() -> authenticate(id, why)); break; }
                    case "save": save(id, m); break;
                    case "notify":
                        if (!foreground) Notifier.show(MainActivity.this, m.optString("title"), m.optString("body"), m.optString("sound"));
                        break;
                    case "google": reply(id, false); break; // الدخول بجوجل غير مفعّل في التطبيق
                    default: reply(id, true);
                }
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public String getVersion() { return Updater.localName(MainActivity.this); }
        @JavascriptInterface public boolean hasSecret() { return SecureStore.get(MainActivity.this) != null; }
        @JavascriptInterface public void saveSecret(String v) { if (v != null && !v.isEmpty()) SecureStore.put(MainActivity.this, v); }
        @JavascriptInterface public void clearSecret() { SecureStore.clear(MainActivity.this); }

        /** دخول بالبصمة/الوجه: يعيد الكود المحفوظ إلى الصفحة (أو null). */
        @JavascriptInterface
        public void unlock() {
            runOnUiThread(() -> biometric("الدخول بالبصمة أو الوجه", "لوحة د. وائل", r -> {
                String code = "ok".equals(r) ? SecureStore.get(MainActivity.this) : null;
                jsCall("onUnlock", code == null ? "null" : JSONObject.quote(code));
            }));
        }

        /** تحقق بايومتري (وجه/بصمة) عند أول دخول. */
        @JavascriptInterface
        public void verifyBio() {
            runOnUiThread(() -> biometric("تحقق من هويتك", "أول دخول على هذا الجهاز", r -> jsCall("onBio", JSONObject.quote(r))));
        }

        @JavascriptInterface public void checkUpdate() { Updater.check(MainActivity.this, updListener); }

        @JavascriptInterface
        public void installUpdate() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) { }
                    jsCall("onInstall", "\"perm\"");
                    return;
                }
                Updater.download(MainActivity.this, updListener);
            });
        }
    }
}
