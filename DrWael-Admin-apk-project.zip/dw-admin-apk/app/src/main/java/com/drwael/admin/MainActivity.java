package com.drwael.admin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {
    private static final String HOST = "appassets.androidplatform.net";
    static volatile boolean foreground = false;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private ActivityResultLauncher<Intent> picker;
    private ActivityResultLauncher<String> notifPerm;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        // منع لقطات الشاشة وتسجيل الشاشة وظهور المحتوى في قائمة التطبيقات الأخيرة
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        super.onCreate(b);

        Notifier.createChannels(this);

        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData()));
                fileCb = null;
            }
        });
        notifPerm = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> startKeepAlive());

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setSaveFormData(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        web.setBackgroundColor(0xFF0B1331);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                if ("https".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    picker.launch(p.createIntent());
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("https://" + HOST + "/assets/admin.html");

        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            startKeepAlive();
        }
    }

    private void startKeepAlive() {
        try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); } catch (Exception ignored) { }
    }

    @Override protected void onResume() { super.onResume(); foreground = true; }
    @Override protected void onPause() { foreground = false; super.onPause(); }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); }
        super.onDestroy();
    }

    private void reply(int id, boolean ok) {
        if (id == 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("ok", ok);
            final String js = "window.DWNative&&window.DWNative.onmessage&&window.DWNative.onmessage({data:" + JSONObject.quote(o.toString()) + "})";
            runOnUiThread(() -> web.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    private void authenticate(int id, String why) {
        int allowed = Build.VERSION.SDK_INT >= 30
                ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
        if (BiometricManager.from(this).canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            reply(id, true); // لا يوجد قفل/بصمة على الجهاز
            return;
        }
        BiometricPrompt.PromptInfo.Builder pb = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("تأكيد الهوية")
                .setSubtitle(why == null || why.isEmpty() ? "لوحة د. وائل" : why)
                .setAllowedAuthenticators(allowed);
        if (Build.VERSION.SDK_INT < 30) pb.setNegativeButtonText("إلغاء");
        new BiometricPrompt(this, ContextCompat.getMainExecutor(this), new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { reply(id, true); }
            @Override public void onAuthenticationError(int code, CharSequence msg) { reply(id, false); }
        }).authenticate(pb.build());
    }

    private void save(int id, JSONObject m) {
        new Thread(() -> {
            try {
                String name = m.optString("name", "file").replaceAll("[\\\\/:*?\"<>|]", "_");
                String mime = m.optString("mime", "application/octet-stream");
                byte[] data = Base64.decode(m.optString("b64", ""), Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new RuntimeException("insert");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(data); }
                } else {
                    File d = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    try (FileOutputStream os = new FileOutputStream(new File(d, name))) { os.write(data); }
                }
                reply(id, true);
            } catch (Exception e) {
                reply(id, false);
            }
        }).start();
    }

    private class Bridge {
        @JavascriptInterface
        public void postMessage(String s) {
            try {
                JSONObject m = new JSONObject(s);
                final int id = m.optInt("id");
                switch (m.optString("a")) {
                    case "auth": { final String why = m.optString("why"); runOnUiThread(() -> authenticate(id, why)); break; }
                    case "save": save(id, m); break;
                    case "notify":
                        if (!foreground) Notifier.show(MainActivity.this, m.optString("title"), m.optString("body"), m.optString("sound"));
                        break;
                    case "google": reply(id, false); break; // الدخول بجوجل غير مفعّل في التطبيق
                    default: reply(id, true);
                }
            } catch (Exception ignored) { }
        }
    }
}
