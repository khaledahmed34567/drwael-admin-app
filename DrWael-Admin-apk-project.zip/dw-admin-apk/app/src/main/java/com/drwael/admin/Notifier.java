package com.drwael.admin;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

/** قنوات إشعارات بأصوات مختلفة: لكل صوت قناة (لأن صوت القناة لا يتغير بعد إنشائها). */
final class Notifier {
    static final String[] SOUNDS = {"chime", "bell", "cash", "pop", "alert", "drop"};
    private static int seq = 100;

    static void createChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        for (String s : SOUNDS) {
            int res = c.getResources().getIdentifier(s, "raw", c.getPackageName());
            NotificationChannel ch = new NotificationChannel("dw_s_" + s, "صوت: " + s, NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + res), aa);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        NotificationChannel off = new NotificationChannel("dw_s_off", "صامت", NotificationManager.IMPORTANCE_LOW);
        off.setSound(null, null);
        nm.createNotificationChannel(off);
        NotificationChannel keep = new NotificationChannel("dw_keep", "التشغيل في الخلفية", NotificationManager.IMPORTANCE_MIN);
        keep.setSound(null, null);
        nm.createNotificationChannel(keep);
    }

    static void show(Context c, String title, String body, String sound) {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        String id = "dw_s_off";
        for (String s : SOUNDS) if (s.equals(sound)) id = "dw_s_" + s;
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, id)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setColor(0xFFF5A83A);
        try {
            NotificationManagerCompat.from(c).notify(seq++ % 900 + 100, b.build());
        } catch (SecurityException ignored) { }
    }
}
