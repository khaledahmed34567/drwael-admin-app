package com.drwael.admin;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

/** تخزين مشفّر (مفتاحه داخل Android Keystore) لكود الدخول بعد تفعيل البصمة. */
final class SecureStore {
    private static SharedPreferences prefs(Context c) throws Exception {
        MasterKey mk = new MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
        return EncryptedSharedPreferences.create(c, "dw_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
    }

    static String get(Context c) {
        try { return prefs(c).getString("code", null); } catch (Exception e) { return null; }
    }

    static void put(Context c, String v) {
        try { prefs(c).edit().putString("code", v).apply(); } catch (Exception ignored) { }
    }

    static void clear(Context c) {
        try { prefs(c).edit().remove("code").apply(); } catch (Exception ignored) { }
    }
}
