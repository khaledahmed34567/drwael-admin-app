package com.drwael.admin;

import android.content.Context;
import android.content.pm.PackageInfo;

import androidx.core.content.pm.PackageInfoCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** يفحص آخر Release على GitHub، وينزّل الـ APK ويجهّزه للتثبيت. */
final class Updater {
    static final String REPO = "khaledahmed34567/drwael-admin-app";
    static volatile JSONObject latest;

    interface Listener {
        void onUpdate(JSONObject o);
        void onProgress(int pct);
        void onDownloaded(File f);
        void onError(String m);
    }

    static int localCode(Context c) {
        try {
            PackageInfo p = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return (int) PackageInfoCompat.getLongVersionCode(p);
        } catch (Exception e) { return 0; }
    }

    static String localName(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    static int parseCode(String tag) {
        Matcher m = Pattern.compile("(\\d+)\\s*$").matcher(tag == null ? "" : tag);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toString("UTF-8");
    }

    static void check(final Context c, final Listener l) {
        new Thread(() -> {
            try {
                HttpURLConnection h = (HttpURLConnection) new URL("https://api.github.com/repos/" + REPO + "/releases/latest").openConnection();
                h.setRequestProperty("Accept", "application/vnd.github+json");
                h.setRequestProperty("User-Agent", "DrWaelAdmin");
                h.setConnectTimeout(10000);
                h.setReadTimeout(15000);
                if (h.getResponseCode() != 200) return;
                JSONObject j = new JSONObject(readAll(h.getInputStream()));
                String tag = j.optString("tag_name");
                int code = parseCode(tag);
                JSONArray as = j.optJSONArray("assets");
                String url = null;
                long size = 0;
                if (as != null) for (int i = 0; i < as.length(); i++) {
                    JSONObject a = as.getJSONObject(i);
                    if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); size = a.optLong("size"); break; }
                }
                if (url == null) return;
                JSONObject o = new JSONObject();
                boolean has = code > localCode(c);
                o.put("has", has);
                o.put("name", tag.replaceFirst("^v", ""));
                o.put("url", url);
                o.put("size", size);
                latest = has ? o : null;
                l.onUpdate(o);
            } catch (Exception ignored) { }
        }).start();
    }

    static void download(final Context c, final Listener l) {
        final JSONObject o = latest;
        if (o == null) { l.onError("لا يوجد تحديث"); return; }
        final String url = o.optString("url");
        if (!url.startsWith("https://github.com/" + REPO + "/releases/download/")) { l.onError("رابط غير موثوق"); return; }
        new Thread(() -> {
            try {
                File dir = new File(c.getCacheDir(), "updates");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, "update.apk");
                HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
                h.setRequestProperty("User-Agent", "DrWaelAdmin");
                h.setConnectTimeout(15000);
                h.setReadTimeout(30000);
                if (h.getResponseCode() != 200) { l.onError("تعذر التحميل"); return; }
                long total = h.getContentLengthLong() > 0 ? h.getContentLengthLong() : o.optLong("size");
                long got = 0;
                int last = -1;
                try (InputStream in = h.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
                    byte[] b = new byte[16384];
                    int n;
                    while ((n = in.read(b)) > 0) {
                        out.write(b, 0, n);
                        got += n;
                        if (total > 0) {
                            int p = (int) (got * 100 / total);
                            if (p != last && p % 2 == 0) { last = p; l.onProgress(p); }
                        }
                    }
                }
                l.onDownloaded(f);
            } catch (Exception e) {
                l.onError("تعذر التحميل");
            }
        }).start();
    }
}
